// Index.php
<?php
require_once '../src/database.php';

$db = (new Database())->connect();
$searchQuery = '';
$filterStatus = isset($_GET['status']) ? $_GET['status'] : '';

if ($filterStatus) {
    $searchQuery = "WHERE status = :status";
}

$query = $db->prepare("SELECT * FROM leads $searchQuery LIMIT 10");
if ($filterStatus) {
    $query->bindParam(':status', $filterStatus);
}
$query->execute();
$leads = $query->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Leads</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }
    </style>
</head>
<body>
    <h2>Leads Information</h2>
    <form method="GET">
        <select name="status">
            <option value="">All Status</option>
            <option value="New" <?= $filterStatus == 'New' ? 'selected' : '' ?>>New</option>
            <option value="In Progress" <?= $filterStatus == 'In Progress' ? 'selected' : '' ?>>In Progress</option>
            <option value="Closed" <?= $filterStatus == 'Closed' ? 'selected' : '' ?>>Closed</option>
        </select>
        <button type="submit">Filter</button>
    </form>
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Status</th>
                <th>Date Added</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (isset($leads) && count($leads) > 0): ?>
                <?php foreach ($leads as $lead): ?>
                    <tr>
                        <td><?= htmlspecialchars($lead['name']) ?></td>
                        <td><?= htmlspecialchars($lead['email']) ?></td>
                        <td><?= htmlspecialchars($lead['phone']) ?></td>
                        <td><?= htmlspecialchars($lead['status']) ?></td>
                        <td><?= htmlspecialchars($lead['date_added']) ?></td>
                        <td>
                            <a href="update.php?id=<?= $lead['id'] ?>">Update</a> |
                            <a href="delete.php?id=<?= $lead['id'] ?>">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">No leads found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
