<?php
require '../vendor/autoload.php';
require '../src/database.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

$db = (new Database())->connect();
$query = $db->query("SELECT name, email, phone, status, date_added FROM leads");
$data = $query->fetchAll(PDO::FETCH_ASSOC);

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->fromArray(array_merge([['Name', 'Email', 'Phone', 'Status', 'Date Added']], $data));

$writer = new Xlsx($spreadsheet);

// Save the file
$filePath = 'leads_export_' . time() . '.xlsx'; 
$writer->save($filePath);
echo "Export complete. File saved as $filePath.";
?>
