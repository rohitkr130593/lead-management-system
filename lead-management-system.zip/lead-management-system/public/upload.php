<!DOCTYPE html>
<html>
<head>
    <title>Upload Leads</title>
</head>
<body>
    <form action="import_excel.php" method="post" enctype="multipart/form-data">
        <input type="file" name="excel_file" accept=".xls, .xlsx" required>
        <button type="submit">Upload</button>
    </form>
</body>
</html>
