<?php
// Database configuration
define('DB_HOST', 'localhost');  // Your database host (usually localhost)
define('DB_NAME', 'lead_management');  // Your database name
define('DB_USERNAME', 'root');  // Your database username (usually root for XAMPP/WAMP)
define('DB_PASSWORD', '');  // Your database password (leave empty for default XAMPP/WAMP setup)
?>
