
<?php
require '../vendor/autoload.php';
require '../src/database.php';
require '../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['excel_file'])) {
    if ($_FILES['excel_file']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['excel_file']['tmp_name'];
        try {
            $spreadsheet = IOFactory::load($file);
            $data = $spreadsheet->getActiveSheet()->toArray();
            $db = (new Database())->connect();
            $stmt = $db->prepare("INSERT INTO leads (name, email, phone, status) VALUES (?, ?, ?, ?)");
            $success = 0;
            $fail = 0;
            
            foreach ($data as $index => $row) {
                if ($index == 0) continue; // Skip header row
                [$name, $email, $phone, $status] = $row;

                if ($name && $email && $phone && in_array($status, ['New', 'In Progress', 'Closed'])) {
                    // Check if email is unique
                    $checkStmt = $db->prepare("SELECT COUNT(*) FROM leads WHERE email = ?");
                    $checkStmt->execute([$email]);
                    $emailExists = $checkStmt->fetchColumn();
                    if ($emailExists) {
                        $fail++;
                        continue;
                    }

                    // Validate phone number
                    if (!preg_match("/^\d{10}$/", $phone)) {
                        $fail++;
                        continue;
                    }

                    try {
                        $stmt->execute([$name, $email, $phone, $status]);
                        $success++;
                    } catch (Exception $e) {
                        $fail++;
                    }
                } else {
                    $fail++;
                }
            }
            echo "Import complete: $success success, $fail failed.";
        } catch (Exception $e) {
            echo "Error reading the Excel file: " . $e->getMessage();
        }
    } else {
        echo "File upload error: " . $_FILES['excel_file']['error'];
    }
}
?>
